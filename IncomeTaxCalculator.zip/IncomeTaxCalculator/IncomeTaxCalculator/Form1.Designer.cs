﻿namespace IncomeTaxCalculator
{
    partial class frmIncomeTaxCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTaxableIncome = new System.Windows.Forms.Label();
            this.lblIncomeTaxOwed = new System.Windows.Forms.Label();
            this.txtTaxableIncome = new System.Windows.Forms.TextBox();
            this.txtIncomeTaxOwed = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblFICA = new System.Windows.Forms.Label();
            this.txtFICA = new System.Windows.Forms.TextBox();
            this.lblMedicare = new System.Windows.Forms.Label();
            this.txtMedicare = new System.Windows.Forms.TextBox();
            this.lvlStateTax = new System.Windows.Forms.Label();
            this.txtStateTax = new System.Windows.Forms.TextBox();
            this.lblNetIncome = new System.Windows.Forms.Label();
            this.txtNetIncome = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblTaxableIncome
            // 
            this.lblTaxableIncome.AutoSize = true;
            this.lblTaxableIncome.Location = new System.Drawing.Point(49, 45);
            this.lblTaxableIncome.Name = "lblTaxableIncome";
            this.lblTaxableIncome.Size = new System.Drawing.Size(121, 20);
            this.lblTaxableIncome.TabIndex = 0;
            this.lblTaxableIncome.Text = "Taxable Income";
            // 
            // lblIncomeTaxOwed
            // 
            this.lblIncomeTaxOwed.AutoSize = true;
            this.lblIncomeTaxOwed.Location = new System.Drawing.Point(49, 81);
            this.lblIncomeTaxOwed.Name = "lblIncomeTaxOwed";
            this.lblIncomeTaxOwed.Size = new System.Drawing.Size(136, 20);
            this.lblIncomeTaxOwed.TabIndex = 1;
            this.lblIncomeTaxOwed.Text = "Income Tax Owed";
            // 
            // txtTaxableIncome
            // 
            this.txtTaxableIncome.Location = new System.Drawing.Point(196, 42);
            this.txtTaxableIncome.Name = "txtTaxableIncome";
            this.txtTaxableIncome.Size = new System.Drawing.Size(100, 26);
            this.txtTaxableIncome.TabIndex = 2;
            // 
            // txtIncomeTaxOwed
            // 
            this.txtIncomeTaxOwed.Location = new System.Drawing.Point(196, 78);
            this.txtIncomeTaxOwed.Name = "txtIncomeTaxOwed";
            this.txtIncomeTaxOwed.ReadOnly = true;
            this.txtIncomeTaxOwed.Size = new System.Drawing.Size(100, 26);
            this.txtIncomeTaxOwed.TabIndex = 3;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(96, 278);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(89, 33);
            this.btnCalculate.TabIndex = 4;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(207, 278);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(89, 33);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblFICA
            // 
            this.lblFICA.AutoSize = true;
            this.lblFICA.Location = new System.Drawing.Point(49, 114);
            this.lblFICA.Name = "lblFICA";
            this.lblFICA.Size = new System.Drawing.Size(46, 20);
            this.lblFICA.TabIndex = 6;
            this.lblFICA.Text = "FICA";
            // 
            // txtFICA
            // 
            this.txtFICA.Location = new System.Drawing.Point(196, 111);
            this.txtFICA.Name = "txtFICA";
            this.txtFICA.ReadOnly = true;
            this.txtFICA.Size = new System.Drawing.Size(100, 26);
            this.txtFICA.TabIndex = 7;
            // 
            // lblMedicare
            // 
            this.lblMedicare.AutoSize = true;
            this.lblMedicare.Location = new System.Drawing.Point(49, 149);
            this.lblMedicare.Name = "lblMedicare";
            this.lblMedicare.Size = new System.Drawing.Size(74, 20);
            this.lblMedicare.TabIndex = 8;
            this.lblMedicare.Text = "Medicare";
            // 
            // txtMedicare
            // 
            this.txtMedicare.Location = new System.Drawing.Point(196, 146);
            this.txtMedicare.Name = "txtMedicare";
            this.txtMedicare.ReadOnly = true;
            this.txtMedicare.Size = new System.Drawing.Size(100, 26);
            this.txtMedicare.TabIndex = 9;
            // 
            // lvlStateTax
            // 
            this.lvlStateTax.AutoSize = true;
            this.lvlStateTax.Location = new System.Drawing.Point(49, 186);
            this.lvlStateTax.Name = "lvlStateTax";
            this.lvlStateTax.Size = new System.Drawing.Size(77, 20);
            this.lvlStateTax.TabIndex = 10;
            this.lvlStateTax.Text = "State Tax";
            // 
            // txtStateTax
            // 
            this.txtStateTax.Location = new System.Drawing.Point(196, 183);
            this.txtStateTax.Name = "txtStateTax";
            this.txtStateTax.ReadOnly = true;
            this.txtStateTax.Size = new System.Drawing.Size(100, 26);
            this.txtStateTax.TabIndex = 11;
            // 
            // lblNetIncome
            // 
            this.lblNetIncome.AutoSize = true;
            this.lblNetIncome.Location = new System.Drawing.Point(49, 217);
            this.lblNetIncome.Name = "lblNetIncome";
            this.lblNetIncome.Size = new System.Drawing.Size(91, 20);
            this.lblNetIncome.TabIndex = 12;
            this.lblNetIncome.Text = "Net Income";
            // 
            // txtNetIncome
            // 
            this.txtNetIncome.Location = new System.Drawing.Point(196, 217);
            this.txtNetIncome.Name = "txtNetIncome";
            this.txtNetIncome.ReadOnly = true;
            this.txtNetIncome.Size = new System.Drawing.Size(100, 26);
            this.txtNetIncome.TabIndex = 13;
            // 
            // frmIncomeTaxCalculator
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(386, 383);
            this.Controls.Add(this.txtNetIncome);
            this.Controls.Add(this.lblNetIncome);
            this.Controls.Add(this.txtStateTax);
            this.Controls.Add(this.lvlStateTax);
            this.Controls.Add(this.txtMedicare);
            this.Controls.Add(this.lblMedicare);
            this.Controls.Add(this.txtFICA);
            this.Controls.Add(this.lblFICA);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtIncomeTaxOwed);
            this.Controls.Add(this.txtTaxableIncome);
            this.Controls.Add(this.lblIncomeTaxOwed);
            this.Controls.Add(this.lblTaxableIncome);
            this.Name = "frmIncomeTaxCalculator";
            this.Text = "Income Tax Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTaxableIncome;
        private System.Windows.Forms.Label lblIncomeTaxOwed;
        private System.Windows.Forms.TextBox txtTaxableIncome;
        private System.Windows.Forms.TextBox txtIncomeTaxOwed;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblFICA;
        private System.Windows.Forms.TextBox txtFICA;
        private System.Windows.Forms.Label lblMedicare;
        private System.Windows.Forms.TextBox txtMedicare;
        private System.Windows.Forms.Label lvlStateTax;
        private System.Windows.Forms.TextBox txtStateTax;
        private System.Windows.Forms.Label lblNetIncome;
        private System.Windows.Forms.TextBox txtNetIncome;
    }
}

