﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Arman Abadi
//Homework 5-3
namespace IncomeTaxCalculator
{
    public partial class frmIncomeTaxCalculator : Form
    {
        public frmIncomeTaxCalculator()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal taxableIncome = 0.0m;
            decimal IncomeTaxOwed = 0.0m;
            taxableIncome = Convert.ToDecimal(txtTaxableIncome.Text);
            //calculations for income tax
            if (taxableIncome < 9225.00m)
                IncomeTaxOwed = taxableIncome * 0.10m;

            else if (taxableIncome >= 9225 && taxableIncome < 37450.00m)
                IncomeTaxOwed = 922.50m + (taxableIncome - 9225.00m) * 0.15m;

            else if (taxableIncome >= 37450.00m && taxableIncome < 90750.00m)
                IncomeTaxOwed = 5156.25m + (taxableIncome - 37450.00m) * 0.25m;

            else if (taxableIncome >= 90750.00m && taxableIncome < 189300.00m)
                IncomeTaxOwed = 18481.25m + (taxableIncome - 90750.00m) * 0.28m;

            else if (taxableIncome >= 189300.00m && taxableIncome < 411500.00m)
                IncomeTaxOwed = 46075.25m + (taxableIncome - 189300.00m) * 0.33m;

            else if (taxableIncome >= 411500.00m && taxableIncome < 413200.00m)
                IncomeTaxOwed = 119401.25m + (taxableIncome - 411500.00m) * 0.35m;

            else
                IncomeTaxOwed = 119996.25m + (taxableIncome - 413200.00m) *0.396m;

         txtIncomeTaxOwed.Text = IncomeTaxOwed.ToString("C");

            //Calculate FICA
            decimal fica = taxableIncome * .065m;
            txtFICA.Text = fica.ToString("C");

            //Calculate Medicare
            decimal medicare = taxableIncome * 0.0145m;
            txtMedicare.Text = medicare.ToString("C");

            //Calculate State Tax
            decimal stateTax = taxableIncome * 0.0495m;
            txtStateTax.Text = stateTax.ToString("C");

            //calculate MONTHLY Net Income
            decimal netIncome = (taxableIncome - IncomeTaxOwed - fica - medicare - stateTax) / 12.00m;
            txtNetIncome.Text = netIncome.ToString("C");
        }
    }
}
